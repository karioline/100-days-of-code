for(var i = 0; i <10; i++){
    console.log("hello from hello.js")
}