//create echo function that accepts str and n parameters, string to print, n number of times
function echo(str, n){
    for(; n>0; n--){
        console.log(str)
    }
}

echo("Echo!!!", 10)
echo("Tater Tots", 3)