//create a grader function that accepts an array of intergers, returns integer average

function average(arr){
    var len = 0;
    // for(var i = 0; i< arr.length; i++){
    //     len += arr[i];
    // }
    arr.forEach(function(score){
        len += score;
    })
    return Math.round(len/arr.length);
}


var scores1 = [90, 98, 89, 100, 100, 86, 94];
var s1 = average(scores1);
console.log(s1);

var scores2 = [40, 65, 77, 82, 80, 54, 73, 63, 95, 49];
var s2 = average(scores2);
console.log(s2);