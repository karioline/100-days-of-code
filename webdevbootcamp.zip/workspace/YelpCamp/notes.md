Summary of what we did:

1. added mongoose in (require line)
2. connected to the yelp_camp db, which wasn't created before, but it was created when we first ran the server
3. set up the campground schema, campgroundSchema
4. created the Campground model, compiles schema into a model
5. using inherent methods to get/find and create new campground objects
6. 



REST - a mapping between HTTP routes and CRUD 
     - a pattern of routes we can follow


7 RESTful Routes

name        url             verb       description
=======================================================
INDEX       /dogs           GET     Display a list of all dogs
NEW         /dogs/new       GET     Displays form to make a new dogs
CREATE      /dogs           POST    Add new dog to DB, then redirect somewhere
SHOW        /dogs/:id       GET     Shows/displays info about one dog (id tells us which dog)
EDIT        /dogs/:id/edit  GET     Show edit form for one dog
UPDATE      /dogs/:id       PUT     Update a particular dog, then redirect somewhere
DESTROY     /dogs/:id       DELETE  Delete a particular dog, then redirect somewhere

